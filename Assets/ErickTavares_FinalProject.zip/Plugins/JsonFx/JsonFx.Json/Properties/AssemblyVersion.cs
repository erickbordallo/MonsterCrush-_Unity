/*------------------------------------------------------------------*\
	This is auto-generated code.  All changes will be overwritten.
\*------------------------------------------------------------------*/

#region 1.4.1003.3009

using System.Reflection;

[assembly: AssemblyVersion("1.4.1003.3009")]
[assembly: AssemblyFileVersion("1.4.1003.3009")]

#endregion 1.4.1003.3009
